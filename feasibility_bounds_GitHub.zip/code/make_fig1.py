
import json
import numpy as np
import matplotlib.pyplot as plt

with open('../data/params_fig1.json') as f:
    params = json.load(f)

x, a1 = np.loadtxt('../data/fig1_profiles_caseI.csv', delimiter=',', skiprows=1).T
_, a2 = np.loadtxt('../data/fig1_profiles_caseII.csv', delimiter=',', skiprows=1).T
_, a3 = np.loadtxt('../data/fig1_profiles_caseIII.csv', delimiter=',', skiprows=1).T

fig, axes = plt.subplots(1, 3, figsize=(15, 4), dpi=300)
for ax, y, label in zip(axes, [a1, a2, a3], ['(a)', '(b)', '(c)']):
    ax.plot(x, y)
    ax.set_xlabel('x')
    ax.set_ylabel('a(x)')
    ax.text(0.02, 0.95, label, transform=ax.transAxes,
            fontsize=14, fontweight='bold', va='top')
    ax.set_title('')

plt.tight_layout()
plt.savefig('../figures/Fig1_combined_PRL.png', dpi=300, bbox_inches='tight')
plt.show()
