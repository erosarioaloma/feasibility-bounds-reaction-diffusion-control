This repository reproduces Fig. 1 from the PRL manuscript.

Run:
python code/make_fig1.py
